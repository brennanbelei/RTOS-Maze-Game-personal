/*
 * Application_Code.c
 *
 *  Created on: Jan 24, 2024
 *      Author: brenn
 */
#include "ApplicationCode.h"
#include <stdlib.h>

Marble marble;


float current_gyro_angle_y = 0.0;
float current_gyro_angle_x = 0.0;
float grav_const = 9.80;

int maze_gen_timer_exp = 1;
int counter = 3;

bool init_setup;

GPIO_PinState PREV_BTN_STATE = GPIO_PIN_RESET;
GPIO_PinState BTN_STATE;

int16_t raw_gyro_out_y;
int16_t raw_gyro_out_x;

osTimerId_t phys_timer_id;
osStatus_t phys_timer_status;
StaticTimer_t phys_timer_TCB;

osTimerId_t maze_gen_timer_id;
osStatus_t maze_gen_timer_status;
StaticTimer_t maze_gen_timer_TCB;

osTimerId_t coll_timer_id;
osStatus_t coll_timer_status;
StaticTimer_t coll_timer_TCB;

osTimerId_t LCD_timer_id;
osStatus_t LCD_timer_status;
StaticTimer_t LCD_timer_TCB;

osTimerId_t game_logic_timer_id;
osStatus_t game_logic_timer_status;
StaticTimer_t game_logic_timer_TCB;

osTimerId_t counter_increment_timer_id;
osStatus_t counter_increment_timer_status;
StaticTimer_t counter_increment_timer_TCB;

osTimerId_t counter_decrement_timer_id;
osStatus_t counter_decrement_timer_status;
StaticTimer_t counter_decrement_timer_TCB;

StaticTask_t phys_task_tcb;
uint32_t phys_task_stack[1000]; //not sure how to determine reasonable size here
osThreadId_t phys_task_id;

StaticTask_t game_logic_task_tcb;
uint32_t game_logic_task_stack[1000];
osThreadId_t game_logic_task_id;

StaticTask_t LCD_task_tcb;
uint32_t LCD_task_stack[1000];
osThreadId_t LCD_task_id;

StaticTask_t coll_task_tcb;
uint32_t coll_task_stack[1000]; //not sure how to determine reasonable size here
osThreadId_t coll_task_id;

osSemaphoreId_t phys_timer_sem_id;
osSemaphoreId_t LCD_timer_sem_id;
osSemaphoreId_t coll_timer_sem_id;
osSemaphoreId_t game_logic_timer_sem_id;
//osSemaphoreId_t counter_timer_sem_id;

osEventFlagsId_t event_id;

osMutexId_t marble_setpoint_mutex_id;

const osMutexAttr_t marble_setpoint_mutex_attr = {
  "marble_setpoint_mutex",     // human readable mutex name
  osMutexPrioInherit,  		// attr_bits
};

const osTimerAttr_t phys_timer_attr = {
		.name = "phys timer",
		.cb_mem = &phys_timer_TCB,
		.cb_size = sizeof(phys_timer_TCB),
		.attr_bits = 0,
};

const osTimerAttr_t maze_gen_timer_attr = {
		.name = "maze gen timer",
		.cb_mem = &maze_gen_timer_TCB,
		.cb_size = sizeof(maze_gen_timer_TCB),
		.attr_bits = 0,
};

const osTimerAttr_t LCD_timer_attr = {
		.name = "LCD timer",
		.cb_mem = &LCD_timer_TCB,
		.cb_size = sizeof(LCD_timer_TCB),
		.attr_bits = 0,
};

const osTimerAttr_t coll_timer_attr = {
		.name = "collision timer",
		.cb_mem = &coll_timer_TCB,
		.cb_size = sizeof(coll_timer_TCB),
		.attr_bits = 0,
};

const osTimerAttr_t game_logic_timer_attr = {
		.name = "game logic timer",
		.cb_mem = &game_logic_timer_TCB,
		.cb_size = sizeof(game_logic_timer_TCB),
		.attr_bits = 0,
};

const osThreadAttr_t phys_task_attr = {
		.name = "phys task",
		.attr_bits = 0, //double check this value
		.cb_mem = &phys_task_tcb,
		.cb_size = sizeof(phys_task_tcb), //double check this value
		.stack_mem = &phys_task_stack,
		.stack_size = sizeof(phys_task_stack), //use size of task
		.priority = osPriorityNormal,
};

const osThreadAttr_t LCD_task_attr = {
		.name = "LCD task",
		.attr_bits = 0, //double check this value
		.cb_mem = &LCD_task_tcb,
		.cb_size = sizeof(LCD_task_tcb), //double check this value
		.stack_mem = &LCD_task_stack,
		.stack_size = sizeof(LCD_task_stack), //use size of task
		.priority = osPriorityNormal,
};

const osThreadAttr_t coll_task_attr = {
		.name = "collision task",
		.attr_bits = 0, //double check this value
		.cb_mem = &coll_task_tcb,
		.cb_size = sizeof(coll_task_tcb), //double check this value
		.stack_mem = &coll_task_stack,
		.stack_size = sizeof(coll_task_stack), //use size of task
		.priority = osPriorityNormal,
};

const osThreadAttr_t game_logic_task_attr = {
		.name = "game logic task",
		.attr_bits = 0, //double check this value
		.cb_mem = &game_logic_task_tcb,
		.cb_size = sizeof(game_logic_task_tcb), //double check this value
		.stack_mem = &game_logic_task_stack,
		.stack_size = sizeof(game_logic_task_stack), //use size of task
		.priority = osPriorityNormal,
};

void Init_Events (void) {

  event_id = osEventFlagsNew(NULL);

}

void semaphore_init(void){
	LCD_timer_sem_id = osSemaphoreNew(1U, 0U, NULL);
	phys_timer_sem_id = osSemaphoreNew(1U, 0U, NULL);
	coll_timer_sem_id = osSemaphoreNew(1U, 0U, NULL);
	game_logic_timer_sem_id = osSemaphoreNew(1U, 0U, NULL);
	//RED_timer_sem_id = osSemaphoreNew(1U, 0U, NULL);
	//GRN_timer_sem_id = osSemaphoreNew(1U, 0U, NULL);
}

void mutex_init(void){
//	disrpt_state_mutex_id = osMutexNew(&disrpt_state_mutex_attr);
//	if(disrpt_state_mutex_id == NULL){
//		while(1);
//	}
	marble_setpoint_mutex_id = osMutexNew(&marble_setpoint_mutex_attr);
	if(marble_setpoint_mutex_id == NULL){
		while(1);
	}
}

void task_init(){
	//LED_task_id = osThreadNew(drive_LED_task, NULL, &LED_task_attr); //LED driver task
	//coll_task_id = osThreadNew(coll_detect_task, NULL, &coll_task_attr); //gyro reading task
	phys_task_id = osThreadNew(phys_engine_task, NULL, &phys_task_attr); //button reader task
	LCD_task_id = osThreadNew(LCD_display_task, NULL, &LCD_task_attr); //LCD controller task
	coll_task_id = osThreadNew(collision_task, NULL, &coll_task_attr);
	game_logic_task_id = osThreadNew(game_logic_task, NULL, &game_logic_task_attr);
	//game_log_task_id = osThreadNew(vehicle_mon_callback, NULL, &game_log_task_attr); //vehicle monitor task
//	if((LED_task_id == NULL) || (coll_task_id == NULL) || (phys_task_id == NULL) || (LCD_task_id == NULL) || (game_log_task_id == NULL)){
//		while(1);
//	}
	if((phys_task_id == NULL) || (LCD_task_id == NULL) || (coll_task_id == NULL) || (game_logic_task_id == NULL)){
		while(1);
	}
}

void timer_init(){
	phys_timer_id = osTimerNew(phys_timer_callback, osTimerPeriodic, NULL, &phys_timer_attr);
	//maze_gen_timer_id = osTimerNew(maze_gen_timer_callback, osTimerOnce, NULL, &maze_gen_timer_attr);
	LCD_timer_id = osTimerNew(LCD_timer_callback, osTimerPeriodic, NULL, &LCD_timer_attr);
	coll_timer_id = osTimerNew(coll_timer_callback, osTimerPeriodic, NULL, &coll_timer_attr);
	game_logic_timer_id = osTimerNew(game_logic_timer_callback, osTimerPeriodic, NULL, &game_logic_timer_attr);
	counter_increment_timer_id = osTimerNew(increment_timer_callback, osTimerPeriodic, NULL, NULL);
	counter_decrement_timer_id = osTimerNew(decrement_timer_callback, osTimerPeriodic, NULL, NULL);
	//GRN_LED_timer_id = osTimerNew(GRN_LED_timer_callback, osTimerPeriodic, NULL, &GRN_LED_timer_attr);
	//RED_LED_timer_id = osTimerNew(RED_LED_timer_callback, osTimerOnce, NULL, &RED_LED_timer_attr);
	uint32_t phys_timer_delay = 20U; //20 ms delay between samples 1000*(0.02)
	uint32_t LCD_timer_delay = 30U;
	uint32_t coll_timer_delay = 20U;
	uint32_t game_logic_timer_delay = 30U;
	if ((phys_timer_id != NULL) && (LCD_timer_id != NULL) && (coll_timer_id != NULL) && (game_logic_timer_id != NULL)) {
		//TODO: Finish this part


//		uint16_t gyro_timer_delay = 100U;
//		uint16_t LCD_timer_delay = 100U;
//		LCD_timer_status = osTimerStart(LCD_timer, LCD_timer_delay);
//		gyro_timer_status = osTimerStart(gyro_timer, gyro_timer_delay);
//		if(dir_alert_status != osOK){
//			while(1);
//		}
//		if(LCD_timer_status != osOK){
//			while(1);
//		}
		coll_timer_status = osTimerStart(coll_timer_id, coll_timer_delay);
		phys_timer_status = osTimerStart(phys_timer_id, phys_timer_delay);
		LCD_timer_status = osTimerStart(LCD_timer_id, LCD_timer_delay);
		game_logic_timer_status = osTimerStart(game_logic_timer_id, game_logic_timer_delay);
	}
	else{
		while(1); //loop to wait
	}
}

//for the gyro demo
//void ApplicationInit(void)
//{
//	timer_init();
//	task_init();
//	semaphore_init();
//
//	Gyro_Init();
//
//	LTCD__Init();
//	LTCD_Layer_Init(0);
//	LCD_Clear(0, LCD_COLOR_BLUE);
//
//	marble.accel_x = 0;
//	marble.accel_y = 0;
//	marble.speed_x = 0;
//	marble.speed_y = 0;
//	marble.center_x_pos = 120;
//	marble.center_y_pos = 160;
//	marble.dx = 0;
//	marble.dy = 0;
//
//
////	timer_init();
////	task_init();
////	semaphore_init();
//
//}

//for the maze demo
//void ApplicationInit(void)
//{
//	Gyro_Init();
//
//	task_init();
//	semaphore_init();
//	timer_init();
//
//	marble.accel_x = 0;
//	marble.accel_y = 0;
//	marble.speed_x = 0;
//	marble.speed_y = 0;
//	marble.center_x_pos = 120;
//	marble.center_y_pos = 160;
//	marble.dx = 0;
//	marble.dy = 0;
//
//	LTCD__Init();
//	LTCD_Layer_Init(0);
//	LCD_Clear(0, LCD_COLOR_BLUE);
//
//	init_setup = true;
//
//	srand(time(NULL));
//	init_maze();
//
//	//Im an actual NPC for not figuring this out sooner -_-
//	bool empty = false;
//	while (empty == false) {
//		update_maze();
//		empty = draw_maze();
//	}
//}

void ApplicationInit(void)
{
	Gyro_Init();

	task_init();
	semaphore_init();
	mutex_init();
	timer_init();
	Init_Events();

	marble.accel_x = 0;
	marble.accel_y = 0;
	marble.speed_x = 0;
	marble.speed_y = 0;
	marble.center_x_pos = 40;
	marble.center_y_pos = 100;
	marble.dx = 0;
	marble.dy = 0;
	marble.disruptor_count = COUNTER;

	LTCD__Init();
	LTCD_Layer_Init(0);
	LCD_Clear(0, LCD_COLOR_BLUE);

	init_setup = true;

}

void phys_timer_callback(void *arg){
		(void)&arg;
		osSemaphoreRelease(phys_timer_sem_id);
}

void maze_gen_timer_callback(void *arg){
		(void)&arg;
		maze_gen_timer_exp = 0;
}

void LCD_timer_callback(void *arg){
		(void)&arg;
		osSemaphoreRelease(LCD_timer_sem_id);
}

void coll_timer_callback(void *arg){
		(void)&arg;
		osSemaphoreRelease(coll_timer_sem_id);
}

void game_logic_timer_callback(void *arg){
	(void)&arg;
	osSemaphoreRelease(game_logic_timer_sem_id);
}

void increment_timer_callback(void *arg){
	(void)&arg;
	osMutexAcquire(marble_setpoint_mutex_id, osWaitForever);
	if(marble.disruptor_count < 3){
		marble.disruptor_count++;
	}
	osMutexRelease(marble_setpoint_mutex_id);
}

void decrement_timer_callback(void *arg){
	(void)&arg;
	osMutexAcquire(marble_setpoint_mutex_id, osWaitForever);
	if(marble.disruptor_count > 0){
		marble.disruptor_count--;
	}
	osMutexRelease(marble_setpoint_mutex_id);
}

void phys_engine_task(void *arg){
	while(1){
		osSemaphoreAcquire(phys_timer_sem_id, osWaitForever);
		//osDelay(1000*(1/50));
		find_gyro_angle(); //this should automatically update the current gyro position global vars
		//float prev_accel_x = marble->accel_x;
		//float prev_accel_y = marble->accel_y;
		//float prev_speed_x = marble.speed_x;
		//float prev_speed_y = marble.speed_y;
		//float prev_dx = marble.dx;
		//float prev_dy = marble.dy;
		osMutexAcquire(marble_setpoint_mutex_id, osWaitForever);

		marble.accel_x = (float)sin((3.14*current_gyro_angle_x)/180) * (grav_const); //double check these because I think these trigs might take doubles instead
		marble.accel_y = (float)sin((3.14*current_gyro_angle_y)/180) * (grav_const);
		marble.speed_x += (marble.accel_x * (0.02)); //this has updated speed of the marble, taking account its previous speed
		marble.speed_y += (marble.accel_y * (0.02));
		marble.dx = (marble.speed_x * (0.02));
		marble.dy = (marble.speed_y * (0.02));

		marble.new_marble_x_pos = marble.center_x_pos + marble.dx;
		marble.new_marble_y_pos = marble.center_y_pos + marble.dy;

////		if((new_marble_x_pos <= 0) || (new_marble_x_pos >= 240))
////		{
////			marble.center_x_pos = marble.center_x_pos;
////		}
//		if(marble.new_marble_x_pos <= 5){
//			marble.center_x_pos = 7;
//			marble.speed_x = 5;
//			marble.dx = 0;
//		}
//		else if(marble.new_marble_x_pos >= 300){
//			marble.center_x_pos = 287;
//			marble.speed_x = -5;
//			marble.dx = 0;
//
//		}
////		if((new_marble_y_pos <= 0) || (new_marble_y_pos >= 320))
////		{
////			marble.center_y_pos = marble.center_y_pos;
////		}
//		else if(marble.new_marble_y_pos <= 5){
//			marble.center_y_pos = 7;
//			marble.speed_y = 5;
//			marble.dy = 0;
//		}
//		//this block seems to have good behavior
//		//the change in speed acts as a sort of bouncing
//		//the reason it has good behavior is because it is the last if
//		//before the else condition
//		else if(marble.new_marble_y_pos >= 200){
//			marble.center_y_pos = 197;
//			marble.speed_y = -5;
//			marble.dy = 0;
//		}
//
//		else{
//			marble.prev_x_pos = marble.center_x_pos;
//			marble.prev_y_pos = marble.center_y_pos;
//			marble.center_x_pos = marble.new_marble_x_pos;
//			marble.center_y_pos = marble.new_marble_y_pos;
//
//
//		}
		osMutexRelease(marble_setpoint_mutex_id);
		//LCD_Clear(0, LCD_COLOR_WHITE);

		//LCD_Draw_Circle_Fill((int)marble.center_x_pos, (int)marble.center_y_pos, 2, LCD_COLOR_RED);
		//LCD_DisplayNumber(150, 160, (int)marble.center_y_pos);
		//LCD_DisplayNumber(70, 200, (int)marble.center_x_pos);
	}
}

void LCD_display_task(){

	while(1){
		osStatus_t sem_acq_status;
		sem_acq_status = osSemaphoreAcquire(LCD_timer_sem_id, osWaitForever);
		if(sem_acq_status == osOK){
			//LCD_Clear(0, LCD_COLOR_WHITE); //should color screen background completely white
			//LCD_Draw_Horizontal_Line(0, )
		}
		else{
			while(1); //hang here if the status aint ok
		}
		//this chunk will only run when the screen is to be initialized
		uint32_t eventFlags = osEventFlagsGet(event_id);
		if (eventFlags & GAME_WON_EVENT) {
			// Display the "game won" screen
			LCD_Clear(0, LCD_COLOR_BLACK);

			// Set the text color
			LCD_SetTextColor(LCD_COLOR_GREEN);

			// Set the font
			LCD_SetFont(&Font16x24);

			// Calculate the x and y coordinates to center the text

			// Display the "Game Won" text
			LCD_DisplayString(70, 140, "GAME WON!");
		}
		else{
			if(init_setup == true){
				LTCD__Init();
				LTCD_Layer_Init(0);
				LCD_Clear(0, LCD_COLOR_BLUE);

				srand(time(NULL));
				init_maze();

				//Im an actual NPC for not figuring this out sooner -_-
				bool empty = false;
				while (empty == false) {
					update_maze();
					empty = draw_maze();
				}
				init_setup = false;
				//LCD_Draw_Circle_Fill((int)marble.center_y_pos, (int)marble.center_x_pos, 2, LCD_COLOR_RED);
				osThreadYield();
			}
			else{
	//			LCD_Draw_Circle_Fill((int)marble.prev_y_pos, (int)marble.prev_x_pos, 5, LCD_COLOR_WHITE);
	//			LCD_Draw_Circle_Fill((int)marble.center_y_pos, (int)marble.center_x_pos, 2, LCD_COLOR_BLUE);
				LCD_Draw_Circle_Fill((int)marble.prev_x_pos + 1, (int)marble.prev_y_pos + 1, 2, LCD_COLOR_WHITE);
				LCD_Draw_Circle_Fill((int)marble.prev_x_pos - 1, (int)marble.prev_y_pos - 1, 2, LCD_COLOR_WHITE);
				LCD_Draw_Circle_Fill((int)marble.prev_x_pos, (int)marble.prev_y_pos, 2, LCD_COLOR_WHITE);
				LCD_Draw_Filled_Square((int)marble.center_x_pos, (int)marble.center_y_pos, 2, LCD_COLOR_RED);
				//LCD_Draw_Circle_Fill((int)marble.center_y_pos, (int)marble.center_x_pos, 2, LCD_COLOR_WHITE);
				//LCD_DisplayNumber(150, 160, (int)marble.center_y_pos);
				//LCD_DisplayNumber(70, 200, (int)marble.center_x_pos);
			}
		}
	}
}

void collision_task(){
	while(1){
		osStatus_t sem_acq_status;
		sem_acq_status = osSemaphoreAcquire(coll_timer_sem_id, osWaitForever);
		if(sem_acq_status == osOK){
			//LCD_Clear(0, LCD_COLOR_WHITE); //should color screen background completely white
			//LCD_Draw_Horizontal_Line(0, )
		}
		else{
			while(1); //hang here if the status aint ok
		}

		osMutexAcquire(marble_setpoint_mutex_id, osWaitForever);
		//the below lines calculate the cell coordinates that the marble is located at
		int marble_cell_x = (int)((marble.center_x_pos - X_SHIFT)/(PATH_WIDTH)); //was (PATH_WIDTH + 1)
		int marble_cell_y = (int)((marble.center_y_pos - Y_SHIFT)/(PATH_WIDTH));

		int x_west_wall = marble_cell_x * PATH_WIDTH +3;
		int x_east_wall = (marble_cell_x + 1) * PATH_WIDTH - 2;
		int y_north_wall = marble_cell_y * PATH_WIDTH +6;
		int y_south_wall = (marble_cell_y + 1) * PATH_WIDTH - 2;

		collision_type collisions = NONE;
		if(BTN_STATE == GPIO_PIN_RESET || (marble.disruptor_count == 0)){
			if( (marble_cell_y == 0 && (int)marble.center_y_pos - y_north_wall <= 1) || ( (int)marble.center_y_pos - y_north_wall <= 1 && (maze[marble_cell_y][marble_cell_x] & CELL_PATH_N) == 0) ){
				collisions |= NORTH_COLL;
				marble.prev_y_pos = marble.center_y_pos;
				marble.center_y_pos = marble.center_y_pos + 1;
				marble.speed_y = 1;

			}
			if( (marble_cell_x == 0 && (int)marble.center_x_pos - x_west_wall <= 1) || ( (int)marble.center_x_pos - x_west_wall <= 1 && (maze[marble_cell_y][marble_cell_x] & CELL_PATH_W) == 0) ){
				collisions |= WEST_COLL;
				marble.prev_x_pos = marble.center_x_pos;
				marble.center_x_pos = marble.center_x_pos + 1;
				marble.speed_x = 1;
			}

			if( x_east_wall - (int)marble.center_x_pos  <= 1 &&(maze[marble_cell_y][marble_cell_x] & CELL_PATH_E) == 0){
				collisions |= EAST_COLL;
				marble.prev_x_pos = marble.center_x_pos;
				marble.center_x_pos = marble.center_x_pos -1;
				marble.speed_x = -1;
			}

	//		if((marble_cell_y == 0 && (int)marble.center_y_pos - y_north_wall <= 1) || ((int)marble.center_y_pos - y_north_wall <= 1 && (maze[marble_cell_y][marble_cell_x] & CELL_PATH_N)) == 0){
	//			collisions |= NORTH_COLL;
	//		}

			if( y_south_wall - (int)marble.center_y_pos <= 1 && (maze[marble_cell_y][marble_cell_x] & CELL_PATH_S) == 0){
				collisions |= SOUTH_COLL;
				marble.prev_y_pos = marble.center_y_pos;
				marble.center_y_pos = marble.center_y_pos -1;
				marble.speed_y = -1;
			}
		}
		if(marble.new_marble_x_pos <= 2){
			marble.center_x_pos = 4;
			marble.speed_x = 1;
					//marble.dx = 0;
		}
		else if(marble.new_marble_x_pos >= (MAZE_WIDTH * PATH_WIDTH)-2){
			marble.center_x_pos = (MAZE_WIDTH * PATH_WIDTH)-4;
			marble.speed_x = -1;
					//marble.dx = 0;

		}
		//		if((new_marble_y_pos <= 0) || (new_marble_y_pos >= 320))
		//		{
		//			marble.center_y_pos = marble.center_y_pos;
		//		}
		else if(marble.new_marble_y_pos <= 2){
			marble.center_y_pos = 4;
			marble.speed_y = 1;
					//marble.dy = 0;
		}
				//this block seems to have good behavior
				//the change in speed acts as a sort of bouncing
				//the reason it has good behavior is because it is the last if
				//before the else condition
		else if(marble.new_marble_y_pos >= (MAZE_WIDTH * PATH_WIDTH)-2){
			marble.center_y_pos = (MAZE_WIDTH * PATH_WIDTH)-4;
			marble.speed_y = -1;
					//marble.dy = 0;
		}
		else{
			marble.prev_x_pos = marble.center_x_pos;
			marble.prev_y_pos = marble.center_y_pos;
			marble.center_x_pos = marble.new_marble_x_pos;
			marble.center_y_pos = marble.new_marble_y_pos;


		}
		osMutexRelease(marble_setpoint_mutex_id);


	}
}

void game_logic_task(){
	while(1){
		osStatus_t sem_acq_status;
		sem_acq_status = osSemaphoreAcquire(game_logic_timer_sem_id, osWaitForever);
		if(sem_acq_status == osOK){
			//LCD_Clear(0, LCD_COLOR_WHITE); //should color screen background completely white
			//LCD_Draw_Horizontal_Line(0, )
		}
		else{
			while(1); //hang here if the status aint ok
		}

		osMutexAcquire(marble_setpoint_mutex_id, osWaitForever);

		int marble_cell_x = (int)((marble.center_x_pos - X_SHIFT) / (PATH_WIDTH + 1));
		int marble_cell_y = (int)((marble.center_y_pos - Y_SHIFT) / (PATH_WIDTH + 1));

		 // Check if the marble has reached the final_cell
		 if (marble_cell_x == final_cell.x && marble_cell_y == final_cell.y) {
			 osEventFlagsSet(event_id, GAME_WON_EVENT);
		 }
		 if(BTN_STATE == GPIO_PIN_SET){
		 	if(counter_decrement_timer_id == NULL){
		 		counter_decrement_timer_id = osTimerNew(decrement_timer_callback, osTimerPeriodic, NULL, NULL);
		 		osTimerStart(counter_decrement_timer_id, 1000U);

		 	}
		 	if(counter_increment_timer_id != NULL){
		 		osTimerStop(counter_increment_timer_id);
		 		osTimerDelete(counter_increment_timer_id);
		 		counter_increment_timer_id = NULL;
		 	}
		 }
		 if(BTN_STATE == GPIO_PIN_RESET){
		 	if(counter_increment_timer_id == NULL){
		 		counter_increment_timer_id = osTimerNew(increment_timer_callback, osTimerPeriodic, NULL, NULL);
		 		osTimerStart(counter_increment_timer_id, 1000U);
		 	}
		 	if(counter_decrement_timer_id != NULL){
		 		osTimerStop(counter_decrement_timer_id);
		 		osTimerDelete(counter_decrement_timer_id);
		 		counter_decrement_timer_id = NULL;
		 	}
		 }
		 if(BTN_STATE == GPIO_PIN_SET && (marble.disruptor_count > 0)){
			 HAL_GPIO_WritePin(RED_LED_PORT, RED_LED_PIN, 0);
			 HAL_GPIO_WritePin(GRN_LED_PORT, GRN_LED_PIN, 1);
		 }
		 else if(BTN_STATE == GPIO_PIN_SET && (marble.disruptor_count == 0)){
			 HAL_GPIO_WritePin(GRN_LED_PORT, GRN_LED_PIN, 0);
			 HAL_GPIO_WritePin(RED_LED_PORT, RED_LED_PIN, 1);
		 }
		 else if(BTN_STATE == GPIO_PIN_RESET && (marble.disruptor_count == COUNTER)){
			 HAL_GPIO_WritePin(RED_LED_PORT, RED_LED_PIN, 0);
			 HAL_GPIO_WritePin(GRN_LED_PORT, GRN_LED_PIN, 1);
		 }

		osMutexRelease(marble_setpoint_mutex_id);
	}
}

void find_gyro_angle(){
	//this is basically a riemann sum of the gyro angular velocities
	//each angular velocity is multiplied by the time between each gyro sample
	//I may need to increase the frequency of gyro samples made
	//raw_gyro_out_y = (Gyro_Get_Velocity_Y());
	//raw_gyro_out_x = (Gyro_Get_Velocity_X());
	//printf("%d\n", raw_gyro_out_y);
	//printf("%d\n", raw_gyro_out_x);
	//float dps_gyro_out_y;
	//float dps_gyro_out_x;
	//float angular_disp_y;
	//float angular_disp_x;

	//dps_gyro_out_y = (Gyro_Get_Velocity_Y() * SENSITIVITY/1000); //these are both angular velocities in deg/sec
	//dps_gyro_out_x = (Gyro_Get_Velocity_X() * SENSITIVITY/1000);
	float gyro_vel_x = (float)((float)Gyro_Get_Velocity_Y() * (float)(SENSITIVITY/1000));
	float gyro_vel_y = (float)((float)Gyro_Get_Velocity_X() * (float)(SENSITIVITY/1000));

	current_gyro_angle_y = current_gyro_angle_y + (gyro_vel_y * 0.02);
	current_gyro_angle_x = current_gyro_angle_x + (gyro_vel_x * 0.02);

//	LCD_Clear(0, LCD_COLOR_WHITE);
	//LCD_SetTextColor(LCD_COLOR_BLACK);
	//LCD_SetFont(&Font16x24);
	//LCD_DisplayString(70, 140, "x: ");
	//LCD_DisplayString(70, 100, "y: ");
	//LCD_DisplayString(200, 300, "B");

//	LCD_DisplayNumber(150, 160, current_gyro_angle_y);
//	LCD_DisplayNumber(70, 200, current_gyro_angle_x);
	//current_gyro_angle_y = dps_gyro_out_y * (1/50);
	//current_gyro_angle_y = angular_disp_y;
	//printf("%d\n", current_gyro_angle_y);
	//current_gyro_angle_x = angular_disp_x;
	//printf("%d\n", current_gyro_angle_x);

}

void EXTI0_IRQHandler(){
	HAL_NVIC_DisableIRQ(EXTI0_IRQn);

	//sample_btn_status();
	PREV_BTN_STATE = BTN_STATE;
	BTN_STATE = HAL_GPIO_ReadPin(USR_BTN_PORT, USR_BTN_PIN);
	//uint32_t timer_delay = 100U; //tick triggers every 100
	//I want the fully charged disruptor to last for 5 seconds and to take 5 seconds
	//to fully replenish (these values can change later if needed). This determines
	//how much I increment and decrement for each tick of the LED timers.

//	if(BTN_STATE == GPIO_PIN_SET){
//		if(counter_decrement_timer_id == NULL){
//			counter_decrement_timer_id = osTimerNew(decrement_timer_callback, osTimerPeriodic, NULL, NULL);
//			osStatus_t start_status_dec = osTimerStart(counter_decrement_timer_id, 100U);
//
//		}
//		if(counter_increment_timer_id != NULL){
//			osStatus_t stop_status_inc = osTimerStop(counter_increment_timer_id);
//			osStatus_t delete_status_inc = osTimerDelete(counter_increment_timer_id);
//			counter_increment_timer_id = NULL;
//		}
//	}
//	if(BTN_STATE == GPIO_PIN_RESET){
//		if(counter_increment_timer_id == NULL){
//			counter_increment_timer_id = osTimerNew(increment_timer_callback, osTimerPeriodic, NULL, NULL);
//			osStatus_t start_status_inc = osTimerStart(counter_increment_timer_id, 100U);
//		}
//		if(counter_decrement_timer_id != NULL){
//			osStatus_t stop_status_dec = osTimerStop(counter_decrement_timer_id);
//			osStatus_t delete_status_dec = osTimerDelete(counter_decrement_timer_id);
//			counter_decrement_timer_id = NULL;
//		}
//	}
	if(BTN_STATE == GPIO_PIN_SET){
		//HAL_GPIO_WritePin(RED_LED_PORT, RED_LED_PIN, 1);
		//HAL_GPIO_WritePin(GRN_LED_PORT, GRN_LED_PIN, 0);
	}
	else if(BTN_STATE == GPIO_PIN_RESET){
		//HAL_GPIO_WritePin(RED_LED_PORT, RED_LED_PIN, 0);
		//HAL_GPIO_WritePin(GRN_LED_PORT, GRN_LED_PIN, 1);
	}

	__HAL_GPIO_EXTI_CLEAR_FLAG(GPIO_PIN_0);
	HAL_NVIC_EnableIRQ(EXTI0_IRQn);
}



