/*
 * Application_Code.h
 *
 *  Created on: Jan 24, 2024
 *      Author: brenn
 */

#ifndef INC_APPLICATION_CODE_H_
#define INC_APPLICATION_CODE_H_

#include "stm32f4xx_hal.h"
#include <Gyro_Driver.h>
#include "cmsis_os.h"
#include <math.h>

//Port and Pin defs
#define USR_BTN_PORT			GPIOA
#define USR_BTN_PIN				GPIO_PIN_0
#define GRN_LED_PORT			GPIOG
#define GRN_LED_PIN				GPIO_PIN_13
#define RED_LED_PORT			GPIOG
#define RED_LED_PIN				GPIO_PIN_14

#define MAZE_HEIGHT				256			//come back to change these later
#define MAZE_WIDTH				256			//come back to change these later
#define SCALE_FACTOR			2			//maybe come back to try other values

#define GYRO_SAMPLE_RATE 		0.10 		//this is because the gyro is sampling every 100ms
#define GYRO_SCALE_FACTOR 		(500/16383)	//this allows us to translate the number into degrees per second (ie rotational vel)
//might instead be (500/32768) not sure yet


//define global variable to store direction of the gyro rotation
typedef enum{
	//this will have 5 different values
	CCW_FAST,
	CCW_SLOW,
	NEAR_ZERO,
	CW_FAST,
	CW_SLOW,

}gyro_dir;

typedef enum{
	NULL_UPDATE,
	RED_LED_TICK,
	GRN_LED_TICK
}LED_flag_states;

typedef enum{
	COLOR_BLACK,
	COLOR_GRAY,
	COLOR_RED,
	COLOR_WHITE,
	COLOR_BLUE
}cell_colors;

//begin maze struct definition
typedef struct{
	char cells[MAZE_HEIGHT][MAZE_WIDTH];
	uint32_t maze_num;
} Maze;
//end maze struct definition

//begin marble struct definition
typedef struct{
	int center_x_pos;
	int center_y_pos;
	float dx;
	float dy;
	int disruptor_state;
	int radius;


} Marble;
//end marble struct definition

//begin initialization function declarations
void app_init();

void timer_init();

void RED_LED_timer_init();

void GRN_LED_timer_init();

void phys_timer_init();

void LCD_timer_init();

void event_init();

void mutex_init();

void semaphore_init();

void task_init();
//end initialization function declarations

//begin timer callback function declarations
void phys_timer_callback();

void RED_LED_timer_callback();

void GRN_LED_timer_callback();

void LCD_timer_callback();
//end timer callback function declarations

//begin task function declarations
void drive_LED_task();

void coll_detect_task();

void phys_engine_task();

void game_logic_task();

void LCD_display_task();
//end task function declarations

//begin helper function declarations
void btn_status();

gyro_dir find_gyro_rotation();

void find_gyro_angle();

void maze_gen();

void draw_maze_scaled();

void draw_maze_unscaled();

void lcd_set_pixel();

void gyro_tilt_calc();
//end helper function declarations

#endif /* INC_APPLICATION_CODE_H_ */
