/*
 * Application_Code.h
 *
 *  Created on: Jan 24, 2024
 *      Author: brenn
 */

#ifndef INC_APPLICATION_CODE_H_
#define INC_APPLICATION_CODE_H_

#include "stm32f4xx_hal.h"
#include <Gyro_Driver.h>
#include "cmsis_os.h"
#include <math.h>
#include "LCD_Driver.h"
#include "maze_gen_test.h"
#include <stdbool.h>

//Port and Pin defs
#define USR_BTN_PORT			GPIOA
#define USR_BTN_PIN				GPIO_PIN_0
#define GRN_LED_PORT			GPIOG
#define GRN_LED_PIN				GPIO_PIN_13
#define RED_LED_PORT			GPIOG
#define RED_LED_PIN				GPIO_PIN_14
#define GAME_WON_EVENT			0x00000001
#define COUNTER 				3


#define GYRO_SAMPLE_RATE 		0.10 		//this is because the gyro is sampling every 100ms
#define GYRO_SCALE_FACTOR 		(500/16383)	//this allows us to translate the number into degrees per second (ie rotational vel)
//might instead be (500/32768) not sure yet


//define global variable to store direction of the gyro rotation
typedef enum{
	//this will have 5 different values
	CCW_FAST,
	CCW_SLOW,
	NEAR_ZERO,
	CW_FAST,
	CW_SLOW,

}gyro_dir;

typedef enum{
	NULL_UPDATE,
	RED_LED_TICK,
	GRN_LED_TICK
}LED_flag_states;

typedef enum{
	COLOR_BLACK,
	COLOR_GRAY,
	COLOR_RED,
	COLOR_WHITE,
	COLOR_BLUE
}cell_colors;

typedef enum{
	NONE,
	WEST_COLL,
	EAST_COLL,
	NORTH_COLL,
	SOUTH_COLL
}collision_type;

//begin maze struct definition
//typedef struct{
//	int maze_width_x;
//	int maze_height_y;
//
//} Maze;
//
//typedef struct{
//	int cell_coord_x;
//	int cell_coord_y;
//	int cell_center_x;
//	int cell_center_y;
//	//this array will hold integers that specify the location of walls
//	//1 will indicate a wall at that side, 0 will indicate opening on that side
//	//{left, right, up, down} ---> {1, 0, 0, 1}
//	int cell_walls[4];
//
//}Cell;
//end maze struct definition

//begin marble struct definition
typedef struct{
	float center_x_pos;
	float center_y_pos;
	float prev_x_pos;
	float prev_y_pos;
	float new_marble_x_pos;
	float new_marble_y_pos;
	float speed_x;
	float speed_y;
	float accel_x;
	float accel_y;
	float dx;
	float dy;
	int disruptor_count;
	int radius;


} Marble;


//end marble struct definition

//begin initialization function declarations
void ApplicationInit();

void timer_init();

//void RED_LED_timer_init();

//void GRN_LED_timer_init();

void phys_timer_init();

void LCD_timer_init();

//void event_init();

//void mutex_init();

void semaphore_init();

void task_init();
//end initialization function declarations

//begin timer callback function declarations
void phys_timer_callback();

void maze_gen_timer_callback(void *arg);

//void RED_LED_timer_callback();

//void GRN_LED_timer_callback();

void LCD_timer_callback();

void coll_timer_callback();

void game_logic_timer_callback();

void decrement_timer_callback();

void increment_timer_callback();

//end timer callback function declarations

//begin task function declarations
//void drive_LED_task();

//void coll_detect_task();

void phys_engine_task(void *arg);

//void game_logic_task();

void LCD_display_task();

void collision_task();

void game_logic_task();
//end task function declarations

//begin helper function declarations
//void btn_status();

//gyro_dir find_gyro_rotation();

void find_gyro_angle();

//void maze_gen();

//void draw_maze_scaled();

//void draw_maze_unscaled();

//void lcd_set_pixel();

//void gyro_tilt_calc();
//end helper function declarations

#endif /* INC_APPLICATION_CODE_H_ */
