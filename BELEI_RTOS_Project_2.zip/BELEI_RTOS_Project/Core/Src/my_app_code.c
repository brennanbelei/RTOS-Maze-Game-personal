/*
 * Application_Code.c
 *
 *  Created on: Jan 24, 2024
 *      Author: brenn
 */
#include "my_app_code.h"
#include <stdlib.h>

#define MSGQUEUE_OBJECTS 16

GPIO_PinState PREV_BTN_STATE = GPIO_PIN_RESET;
GPIO_PinState BTN_STATE;
gyro_dir app_gyro_dir;

//adding new global variables for the project
//this may get changed but for now I think I want it as a global
uint32_t disruptor_charge = 5000U; //this effectively represents 5 seconds of total charge

float current_gyro_angle_y = 0.0;
float current_gyro_angle_x = 0.0;

Marble marble;
Maze maze;

//end adding new global variables for the project

//double check this
static uint32_t exec1 = 1;

//adding global variable for phase 2
//act as counter for the systick callback
int tick_num = 1;
//In the user manual of the STM32 I read that:
	//"By default, this function is called each 1ms in Systick ISR."
int tick_max = 100;

//begin timer vars declaration
osTimerId_t my_timer;
osStatus_t timer_status;
StaticTimer_t my_TCB; //where in the documentation is a StaticTimer_t and what is a TCB

osTimerId_t phys_timer_id;
osStatus_t phys_timer_status;
StaticTimer_t phys_timer_TCB;

osTimerId_t LCD_timer_id;
osStatus_t LCD_timer_status;
StaticTimer_t LCD_timer_TCB;

osTimerId_t GRN_LED_timer_id;
osStatus_t GRN_LED_timer_status;
StaticTimer_t GRN_LED_timer_TCB;

osTimerId_t RED_LED_timer_id;
osStatus_t RED_LED_timer_status;
StaticTimer_t RED_LED_timer_TCB;
//end timer vars declaration

//begin task vars declaration
StaticTask_t LED_task_tcb;
uint32_t LED_task_stack[1000]; //not sure how to determine reasonable size here
osThreadId_t LED_task_id;

StaticTask_t coll_task_tcb;
uint32_t coll_task_stack[1000]; //not sure how to determine reasonable size here
osThreadId_t coll_task_id;

StaticTask_t phys_task_tcb;
uint32_t phys_task_stack[1000]; //not sure how to determine reasonable size here
osThreadId_t phys_task_id;

StaticTask_t LCD_task_tcb;
uint32_t LCD_task_stack[1000];
osThreadId_t LCD_task_id;

StaticTask_t game_log_task_tcb;
uint32_t game_log_task_stack[1000];
osThreadId_t game_log_task_id;

//end task vars declaration

//begin OS synchronization vars declaration
osEventFlagsId_t coll_event_id;
osEventFlagsId_t game_log_event_id;
osEventFlagsId_t LED_event_id;


osMutexId_t disrpt_state_mutex_id;
osMutexId_t pos_setpoint_mutex_id;

osSemaphoreId_t LCD_timer_sem_id;
osSemaphoreId_t phys_timer_sem_id;
//osSemaphoreId_t RED_timer_sem_id;
//osSemaphoreId_t GRN_timer_sem_id;

//end OS synchronization vars declaration

//begin semaphore attribute declaration



//end semaphore attribute declaration

//begin mutex attribute declaration
const osMutexAttr_t disrpt_state_mutex_attr = {
  "disrpt_state_mutex",     // human readable mutex name
  osMutexPrioInherit,  // attr_bits
};

const osMutexAttr_t pos_setpoint_mutex_attr = {
  "pos_setpoint_mutex",     // human readable mutex name
  osMutexPrioInherit,  		// attr_bits
};
//end mutex attribute declaration

//begin timer attribute declaration
const osTimerAttr_t phys_timer_attr = {
		.name = "phys timer",
		.cb_mem = &phys_timer_TCB,
		.cb_size = sizeof(phys_timer_TCB),
		.attr_bits = 0,
};

const osTimerAttr_t LCD_timer_attr = {
		.name = "LCD timer",
		.cb_mem = &LCD_timer_TCB,
		.cb_size = sizeof(LCD_timer_TCB),
		.attr_bits = 0,
};

const osTimerAttr_t GRN_LED_timer_attr = {
		.name = "GRN LED timer",
		.cb_mem = &GRN_LED_timer_TCB,
		.cb_size = sizeof(GRN_LED_timer_TCB),
		.attr_bits = 0,
};

const osTimerAttr_t RED_LED_timer_attr = {
		.name = "RED LED timer",
		.cb_mem = &RED_LED_timer_TCB,
		.cb_size = sizeof(RED_LED_timer_TCB),
		.attr_bits = 0,
};

//end timer attribute declaration

//begin task attribute declaration
const osThreadAttr_t LED_task_attr = {
		.name = "LED task",
		.attr_bits = 0, //double check this value
		.cb_mem = &LED_task_tcb,
		.cb_size = sizeof(LED_task_tcb), //double check this value
		.stack_mem = &LED_task_stack,
		.stack_size = sizeof(LED_task_stack), //use size of task
		.priority = osPriorityNormal,
};

const osThreadAttr_t coll_task_attr = {
		.name = "coll task",
		.attr_bits = 0, //double check this value
		.cb_mem = &coll_task_tcb,
		.cb_size = sizeof(coll_task_tcb), //double check this value
		.stack_mem = &coll_task_stack,
		.stack_size = sizeof(coll_task_stack), //use size of task
		.priority = osPriorityNormal,
};

const osThreadAttr_t phys_task_attr = {
		.name = "phys task",
		.attr_bits = 0, //double check this value
		.cb_mem = &phys_task_tcb,
		.cb_size = sizeof(phys_task_tcb), //double check this value
		.stack_mem = &phys_task_stack,
		.stack_size = sizeof(phys_task_stack), //use size of task
		.priority = osPriorityNormal,
};

const osThreadAttr_t LCD_task_attr = {
		.name = "LCD task",
		.attr_bits = 0, //double check this value
		.cb_mem = &LCD_task_tcb,
		.cb_size = sizeof(LCD_task_tcb), //double check this value
		.stack_mem = &LCD_task_stack,
		.stack_size = sizeof(LCD_task_stack), //use size of task
		.priority = osPriorityNormal,
};

const osThreadAttr_t game_log_task_attr = {
		.name = "game logic task",
		.attr_bits = 0, //double check this value
		.cb_mem = &game_log_task_tcb,
		.cb_size = sizeof(game_log_task_tcb), //double check this value
		.stack_mem = &game_log_task_stack,
		.stack_size = sizeof(game_log_task_stack), //use size of task
		.priority = osPriorityNormal,
};
//end task attribute declaration



//begin declaration of init functions

/*
 * @brief This is the initialization function for my app, it initializes the gyro and the
 * appropriate interrupts using the NVIC
 *
 *
 * @param[in](void)
 * @return (void)
 */
void app_init(){
	//first initialize the gyro

	/*DEBUG NOTES:
	 * I have commented out the osKernelStart call in main and
	 * instead put it in the app_init call.
	 *
	 */

	HAL_GPIO_WritePin(RED_LED_PORT, RED_LED_PIN, 0);
	HAL_GPIO_WritePin(GRN_LED_PORT, GRN_LED_PIN, 0);
	HAL_NVIC_EnableIRQ(EXTI0_IRQn);
	HAL_NVIC_SetPriority(EXTI0_IRQn, 13, 13);

	Gyro_Init();

	//osKernelInitialize();

	timer_init();
	task_init();
	event_init();
	mutex_init();
	semaphore_init();


}

int event_init (void) {
	coll_event_id = osEventFlagsNew(NULL);
	game_log_event_id = osEventFlagsNew(NULL);
	LED_event_id = osEventFlagsNew(NULL);
  if ((coll_event_id == NULL) || (game_log_event_id == NULL) || (LED_event_id == NULL)) {
    // Event Flags object not created, handle failure
    return(-1);
  }
  return(0);
}

void mutex_init(void){
	disrpt_state_mutex_id = osMutexNew(&disrpt_state_mutex_attr);
	if(disrpt_state_mutex_id == NULL){
		while(1);
	}
	pos_setpoint_mutex_id = osMutexNew(&pos_setpoint_mutex_attr);
	if(pos_setpoint_mutex_id == NULL){
		while(1);
	}
}

void semaphore_init(void){
	LCD_timer_sem_id = osSemaphoreNew(1U, 0U, NULL);
	phys_timer_sem_id = osSemaphoreNew(1U, 0U, NULL);
	RED_timer_sem_id = osSemaphoreNew(1U, 0U, NULL);
	GRN_timer_sem_id = osSemaphoreNew(1U, 0U, NULL);
}

void task_init(){
	LED_task_id = osThreadNew(drive_LED_task, NULL, &LED_task_attr); //LED driver task
	coll_task_id = osThreadNew(coll_detect_task, NULL, &coll_task_attr); //gyro reading task
	phys_task_id = osThreadNew(phys_engine_task, NULL, &phys_task_attr); //button reader task
	LCD_task_id = osThreadNew(LCD_display_task, NULL, &LCD_task_attr); //LCD controller task
	game_log_task_id = osThreadNew(vehicle_mon_callback, NULL, &game_log_task_attr); //vehicle monitor task
	if((LED_task_id == NULL) || (coll_task_id == NULL) || (phys_task_id == NULL) || (LCD_task_id == NULL) || (game_log_task_id == NULL)){
		while(1);
	}
}

void timer_init(){
	phys_timer_id = osTimerNew(phys_timer_callback, osTimerOnce, NULL, &phys_timer_attr);
	LCD_timer = osTimerNew(LCD_timer_callback, osTimerPeriodic, NULL, &LCD_timer_attr);
	GRN_LED_timer_id = osTimerNew(GRN_LED_timer_callback, osTimerPeriodic, NULL, &GRN_LED_timer_attr);
	RED_LED_timer_id = osTimerNew(RED_LED_timer_callback, osTimerOnce, NULL, &RED_LED_timer_attr);
	if ((phys_timer_id != NULL) && (LCD_timer != NULL) && (GRN_LED_timer_id != NULL) && (RED_LED_timer_id != NULL)) {
		//TODO: Finish this part


//		uint16_t gyro_timer_delay = 100U;
//		uint16_t LCD_timer_delay = 100U;
//		LCD_timer_status = osTimerStart(LCD_timer, LCD_timer_delay);
//		gyro_timer_status = osTimerStart(gyro_timer, gyro_timer_delay);
//		if(dir_alert_status != osOK){
//			while(1);
//		}
//		if(LCD_timer_status != osOK){
//			while(1);
//		}
	}
	else{
		while(1); //loop to wait
	}
}
//end declaration of init functions

//begin declaration of task functions
void drive_LED_task(void *arg){

	gyro_dir gyro_data;
	LED_flag_states current_flags;

	while(1){
		//current_flags = osEventFlagsWait(LED_event_id, (RED_LED_TICK | GRN_LED_TICK), osFlagsWaitAny, osWaitForever);
		current_flags = osEventFlagsWait(LED_event_id, (RED_LED_TICK | GRN_LED_TICK), osFlagsNoClear, osWaitForever);
		//wait to deal with the event before you clear the flag for it
		if((current_flags | RED_LED_TICK) == RED_LED_TICK){
			//if this is the case then at least the RED LED tick has activated
			//decrement the disruptor_charge var by however much you want for one tick
			//perform the logic to find the duty cycle that the RED LED should tick at
			//and activate it accordingly, likely by using STM32 PWM generation
			//I looked this up and this is going to require me to oonfigure some clock routing
			//information and then inside this function I will specify duty cycle and frequency


			//lastly clear the event flag accordingly
			osEventFlagsClear(LED_event_id, RED_LED_TICK);
		}
		if((currrent_flags | GRN_LED_TICK) == GRN_LED_TICK){
			//if this is the case the the GRN LED tick has been activated
			//increment the disruptor_charge var by however much you want for one tickd
			//perform the logic to find the duty cycle that the GRN LED should tick at
			//and activate it accordingly, likely by using STM32 PWM generation

			//lastly clear the event flag accordingly
			osEventFlagsClear(LED_event_id, GRN_LED_TICK);
		}
	}
}

void phys_engine_task(Marble *marble){

	//come back to this and see if I am missing anything. I lost train of thought overnight
	while(1){
		//the semaphore can be acquired after it is released by the timer every 100ms
		//subsequently I will call the helper function to find the current gyro reading and then its angle
		osSemaphoreAcquire(phys_timer_sem_id, osWaitForever);
		osMutexAcquire(pos_setpoint_mutex_id, osWaitForever);
		find_gyro_angle(); //this should automatically update the current gyro position global vars
		marble->dx = cos(current_gyro_angle_x) * (marble->radius); //double check these because I think these trigs might take doubles instead
		marble->dy = sin(current_gyro_angle_y) * (marble->radius);
		//I'm not sure if I need the mutex because I am only using the marble struct
		//to calculate its new dx and dy, the collision task will be the one acutally updating the marble position
		osMutexRelease(pos_setpoint_mutex_id);
	}
}

void coll_detect_task(Marble *marble, Maze *maze){
	//check to see if I need some kind of os synchronization feature here
	//maybe a timer sem release, or an event from phys, or maybe not
	while(1){
		//I need to compare the current position of the marble to the
		//position of the walls in the maze.

		//pseudo code:
		//if(disruptor_charge == 0 || BTN_STATE == GPIO_PIN_RESET) //then this means the marble cannot clip
			//if(no wall at marble center x + radius + dx)
				//marble center x = marble center x + dx
			//else
				//marble center x = marble center x

			//if(no wall at marble center y + radius + dy
				//marble center y = marble center y + dy

		//if(disruptor_charge != 0 && BTN_STATE == GPIO_PIN_SET)
			//if(no boundary wall at marble center x + radius + dx)
				//marble center x = marble center x + dx
			//else if(boundary wall at marble center x + radius + dx)
				//marble center x = marble center x

			//if(no boundary wall at marble center y + radius + dy)
				//marble center y = marble center y + dy
			//else if(boundary wall at marble center y + radius + dy)
				//marble center y = marble center y
	}
}


//end declaration of task functions

//begin helper function declarations
void maze_gen(Maze *maze){
    // Initialize all cells to be empty
    for (int i = 0; i < MAZE_HEIGHT; i++) {
        for (int j = 0; j < MAZE_WIDTH; j++) {
            maze->cells[i][j] = ' ';
        }
    }
    // Add walls to the maze
    // For simplicity, let's add walls along the perimeter of the maze
    for (int i = 0; i < MAZE_HEIGHT; i++) {
        maze->cells[i][0] = 'B'; // Left boundary
        maze->cells[i][MAZE_WIDTH - 1] = 'B'; // Right boundary
    }
    for (int j = 0; j < MAZE_WIDTH; j++) {
        maze->cells[0][j] = 'B'; // Top boundary
        maze->cells[MAZE_HEIGHT - 1][j] = 'B'; // Bottom boundary
    }
    //for testing purposes I am going to make the first interior wall just a
    //horizontal line down the middle of the screen
    for(j = 0; j < MAZE_WIDTH; j++){
    	maze->cells[(MAZE_HEIGHT/2)][j] = "#"; //middle wall

    }


    // Add interior walls (you can add your own logic to define the maze layout)

    //maze->cells[3][4] = '#';
    //maze->cells[5][7] = '#';
    //also add logic to create holes in the maze
    //also add logic to create set waypoints in the maze
    //add the exit point (where the marble needs to reach)
    //the type of maze generated at this point will depend on a randomly generated number (1-4)

    /*
     * switch(maze->maze_num){
     * 		case 1:
     * 			create maze design number 1
     * 			break;
     * 		case 2:
     * 			create maze design number 2
     * 			break;
     * 		case 3:
     * 			create maze design number 3
     * 			break;
     * 		case 4:
     * 			create maze design number 4
     * 			break;
     * 		default:
     * 			while(1);
     * 			//error, maze not initialized
     * }
     */

    maze->cells[MAZE_HEIGHT - 2][MAZE_WIDTH - 2] = 'E'; //this will put the exit in the corner of the maze, this can be changed if need be
    //this maze object will then be passed to another helper function
    //this helper function will act as a bitmap to translate the maze struct into
    //pixels on the LCD screen
}

//function to draw the maze on the LCD screen without scaling, for testing
void draw_maze_unscaled(Maze *maze) {
    // Loop through each cell in the maze
    for (int y = 0; y < MAZE_HEIGHT; y++) {
        for (int x = 0; x < MAZE_WIDTH; x++) {
            // Set pixel on LCD based on maze data
            if (maze->cells[y][x] == '#') {
                // Draw a wall
                lcd_set_pixel(x, y, COLOR_GRAY);
            }
            else if (maze->cells[y][x] == 'E') {
                // Draw the exit point
                lcd_set_pixel(x, y, COLOR_RED);
            }
            else if(maze->cells[y][x] == 'B')
            	//draw the boundaries
            	lcd_set_pixel(x, y, COLOR_BLACK);
            else {
                // Draw empty space
                lcd_set_pixel(x, y, COLOR_WHITE);
            }
        }
    }
    // Refresh the LCD to update the display
    lcd_refresh();
}

// Function to draw the maze on the LCD screen with scaling
void draw_maze_scaled(Maze *maze) {
    // Loop through each cell in the maze
    for (int y = 0; y < MAZE_HEIGHT; y++) {
        for (int x = 0; x < MAZE_WIDTH; x++) {
            // Calculate coordinates for top-left corner of cell on LCD
            int lcd_x = x * SCALE_FACTOR;
            int lcd_y = y * SCALE_FACTOR;

            // Set pixels on LCD based on maze data
            for (int dy = 0; dy < SCALE_FACTOR; dy++) {
                for (int dx = 0; dx < SCALE_FACTOR; dx++) {
                    if (maze->cells[y][x] == '#') {
                        // Draw a wall
                        lcd_set_pixel(lcd_x + dx, lcd_y + dy, COLOR_GRAY);
                    }
                    else if(maze->cells[y][x] == 'B'){
                    	//draw a boundary
                    	//I think that maybe you dont use scale for boundary
                    	//because it would go beyond the screen and maybe cause error
                    	lcd_set_pixel(lcd_x, lcd_y, COLOR_BLACK);
                    }
                    else if (maze->cells[y][x] == 'E') {
                        // Draw the exit point
                        lcd_set_pixel(lcd_x + dx, lcd_y + dy, COLOR_RED);
                    }
                    else {
                        // Draw empty space
                        lcd_set_pixel(lcd_x + dx, lcd_y + dy, COLOR_WHITE);
                    }
                }
            }
        }
    }
    // Refresh the LCD to update the display
    //lcd_refresh();
}

void lcd_set_pixel(int x_coord, int y_coord, cell_colors color){
	//finish this up

}

void find_gyro_angle(){
	//this is basically a riemann sum of the gyro angular velocities
	//each angular velocity is multiplied by the time between each gyro sample
	//I may need to increase the frequency of gyro samples made
	int16_t raw_gyro_out_y = Gyro_Get_Velocity_Y;
	int16_t raw_gyro_out_x = Gyro_Get_Velocity_X;
	float deg_gyro_out_y;
	float deg_gyro_out_x;
	float angular_disp_y;
	float angular_disp_x;

	deg_gyro_out_y = (float)raw_gyro_out_y * GYRO_SCALE_FACTOR;
	deg_gyro_out_x = (float)raw_gyro_out_x * GYRO_SCALE_FACTOR;
	angular_disp_y = deg_gyro_out_y * GYRO_SAMPLE_RATE
	angular_disp_x = deg_gyro_out_x * GYRO_SAMPLE_RATE;

	current_gyro_angle_y += angular_disp_y;
	current_gyro_angle_x += angular_disp_x;

}

//end helper function declarations


//begin timer callback function declarations
void LCD_timer_callback(void *arg){
		(void)&arg;

		osSemaphoreRelease(LCD_timer_sem_id);
}

void phys_timer_callback(void *arg){
		(void)&arg;
		osSemaphoreRelease(phys_timer_sem_id);
}

void RED_LED_timer_callback(){
	//decrement the disruptor charge accordingly
	//maybe add a mutex acquire and release for the disruptor_charge?
	osMutexAcquire(disrpt_state_mutex_id, osWaitForever);
	if(disruptor_charge >= 0U){
		disruptor_charge = disruptor_charge - 100U;
	}
	osMutexRelease(disrpt_state_mutex_id);
	osEventFlagsSet(LED_event_id, RED_LED_TICK);
}

void GRN_LED_timer_callback(){
	//increment the disruptor charge accordingly
	//maybe add a mutex acquire and release for the disruptor_charge?
	osMutexAcquire(disrpt_state_mutex_id, osWaitForever);
	if(disruptor_charge <= 5000U){
		disruptor_charge = disruptor_charge + 100U;
	}
	osMutexRelease(disrpt_state_mutex_id);
	osEventFlagsSet(LED_event_id, GRN_LED_TICK);
}
//end timer callback function declarations

/*
 * @brief This is the function that calculate the rotation of the gyro
 * it relies on using the provided gyro driver
 *
 * @param[in](void)
 * @return (void)
 */

gyro_dir find_gyro_rotation_y(){
	//I think that since the gyro velocity function produces a 16 bit integer the largest
	//value that it can read is +32767 to -32768
	int16_t gyro_reading_y = Gyro_Get_Velocity_Y();
	int16_t gyro_reading_x = Gyro_Get_Velocity_X();
	gyro_dir gyro_dir_out_y;
	gyro_dir gyro_dir_out_x;
	//gyro_dir gyro_out;
	int zero_buffer = 100;

	if(gyro_reading > 16383){
		gyro_dir_out_y = CW_FAST;
	}
	else if((gyro_reading <= 16383) && (gyro_reading > zero_buffer)){
		gyro_dir_out_y = CW_SLOW;
	}
	else if((gyro_reading >= -16383) && (gyro_reading < -(zero_buffer))){
		gyro_dir_out_y = CCW_SLOW;
	}
	else if((gyro_reading < -16383)){
		gyro_dir_out_y = CCW_FAST;
	}
	else if((gyro_reading < zero_buffer) && (gyro_reading > -(zero_buffer))){
		gyro_dir_out_y = NEAR_ZERO;
	}
}

/*
 * @brief This is the function that drives the LEDs according to
 * the measurements of the gyro as well as the status of the user button.
 * The if statements are tailored such that the test cases as established by
 * the lab write up pass accordingly.
 *
 * @param[in](void)
 * @return (void)
 */

void drive_LEDs(void *arg){
	MSGQUEUE_OBJ_t msg;
	osStatus_t status;
	gyro_dir gyro_dat = 1;
	GPIO_PinState btn_dat = 1;

	//initialze the message struct and the status here
	//inside the while loop, set the value of the data from the gyro and the value of the data from the btn (ie btn state)
	//one of the data bits will be set invalid, indicating that the data packet came from the other task
	//set the pins based on these two vars
	//use the previous instance of the var that was not most recently updated
	//as long as you do this update in the while(1), the variables will be preserved once the task is rescheduled
	while(1){

		//if the msg btn_data is -1 then the data packet that was just sent was
		//from the gyro callback. Therefore, use the new gyro data, and the old btn data
		if(msg.data_sent == 1){
			btn_dat = msg.btn_data;
		}
		else if(msg.data_sent == 0){
			gyro_dat = msg.gyro_data;
		}
		//make sure that in between context switches if the data packet coming in is for
		//gyro, then the last button status is used. And vice versa if btn status comes in.
		if(status == osOK){
			if(btn_dat == 0){
				if(gyro_dat == CCW_FAST || gyro_dat == CCW_SLOW){
					HAL_GPIO_WritePin(RED_LED_PORT, RED_LED_PIN, 0);
					HAL_GPIO_WritePin(GRN_LED_PORT, GRN_LED_PIN, 1);
				}
				else if(gyro_dat == NEAR_ZERO || gyro_dat == CW_FAST || gyro_dat == CW_SLOW){
					HAL_GPIO_WritePin(RED_LED_PORT, RED_LED_PIN, 0);
					HAL_GPIO_WritePin(GRN_LED_PORT, GRN_LED_PIN, 0);
				}
			}
			else if(btn_dat == 1){
				if(gyro_dat == CCW_FAST || gyro_dat == CCW_SLOW){
					HAL_GPIO_WritePin(RED_LED_PORT, RED_LED_PIN, 0);
					HAL_GPIO_WritePin(GRN_LED_PORT, GRN_LED_PIN, 1);
				}
				else if(gyro_dat == NEAR_ZERO || gyro_dat == CW_FAST || gyro_dat == CW_SLOW){
					HAL_GPIO_WritePin(RED_LED_PORT, RED_LED_PIN, 1);
					HAL_GPIO_WritePin(GRN_LED_PORT, GRN_LED_PIN, 1);
				}
			}
		}
	}
}

/*
 * @brief This is the callback function for the systick interrupt
 * the interrupt is called every milisecond and a counter is incremented
 * until reaching 100, wherein the drive_LEDs function is called
 *
 * @param[in](void)
 * @return (void)
 */

//void HAL_SYSTICK_Callback(){
//	//In the user manual of the STM32 I read that:
//	//"By default, this function is called each 1ms in Systick ISR."
//
//	printf("numticks is %d\n", tick_num);
//	tick_num++;
//	//double check this is what they mean by check and drive every 100ms
//	if((tick_num % tick_max) == 0){
//		tick_max = 100;
//		//I think that we take care of the btn status in the btn handler
//		//sample_btn_status();
//		find_gyro_rotation();
//		drive_LEDs();
//		//reset the tick num after sampling and driving LEDs
//		tick_num = 0;
//	}
//}

/*
 * @brief This is the callback function for each instance of a timer created using timer_init
 * once the os timer reaches its set value it calls this function in order to sample the user button
 * find the rotation of the gyro and drive the LEDs accordingly.
 *
 * @param[in](void *arg) the function takes in a void pointer to a location in memory
 * @return (void)
 */

void timer_callback(void *arg){
		(void)&arg;

//		sample_btn_status();
//		find_gyro_rotation();
//		drive_LEDs();

		osSemaphoreRelease(binary_sem_id); //double check this to make sure

}


/*
 * @brief This is the call back function for the GPIO_EXTI interrupt, specifically
 * that of the EXTI0 interrupt, which is the only of the EXTI lines that I have enabled.
 * Every time the user button is pressed this callback is called and the user button status
 * is noted and stored in a global variable.
 *
 * @param[in](void)
 * @return (void)
 */

void EXTI0_IRQHandler(){
	HAL_NVIC_DisableIRQ(EXTI0_IRQn);

	//sample_btn_status();
	PREV_BTN_STATE = BTN_STATE;
	BTN_STATE = HAL_GPIO_ReadPin(USR_BTN_PORT, USR_BTN_PIN);
	uint32_t timer_delay = 100U; //tick triggers every 100
	//I want the fully charged disruptor to last for 5 seconds and to take 5 seconds
	//to fully replenish (these values can change later if needed). This determines
	//how much I increment and decrement for each tick of the LED timers.
	if(BTN_STATE == GPIO_PIN_SET){
		//this indicates that the button has just been pressed
		//therefore begin the Red LED timer
		//the next interrupt to come from the button will be when it is released
		//this will stop the RED timer and begin the green one.
		if(osTimerIsRunning(GRN_LED_timer_id)){
			//if the button is being pressed and the green timer was on
			//we stop it here and then will begin the red timer
			osTimerStop(GRN_LED_timer_id);
		}
		if(!osTimerIsRunning(RED_LED_timer_id)){
			//this starts the red timer, for each tick, the red timer callback
			//will cause the LED driver task to calculate the way in which the LEDs are to flash
			osTimerStart(RED_LED_timer_id, timer_delay);

		}
	}
	else if(BTN_STATE == GPIO_PIN_RESET){
		//if previous state was high then the button is not being
		//held anymore and the deplete timer can stop and the
		//charging timer can start
		if(osTimerIsRunning(RED_LED_timer_id)){
			//if the button is let go and the red timer is going
			//we stop it and then start the green timer
			osTimerStop(RED_LED_timer_id);
		}
		if(!osTimerIsRunning(GRN_LED_timer_id)){
			osTimerStart(GRN_LED_timer_id, timer_delay);
		}
	}

	//osEventFlagsSet(event_id, 0x00000001U);
	//osThreadYield(); //I don't think this IRQ handler is a thread so I don't think I need this line
	__HAL_GPIO_EXTI_CLEAR_FLAG(GPIO_PIN_0);
	HAL_NVIC_EnableIRQ(EXTI0_IRQn);
}

//void task1_callback(void *arg){
//	(void)&arg;
//	while(1){
//		find_gyro_rotation();
//		sample_btn_status();
//		drive_LEDs();
//		osDelay(100);
//	}
//}

void gyro_timer_callback(void *arg){
	//this function is the callback function for the OSTimer creation
	//Upon entry to this function, acquire the semaphore
	//after acquiring, the gyro can make a sample
	//after it makes the sample it releases the semaphore

	gyro_dir gyro_data_y;
	gyro_dir gyro_data_x
	while(1){
		MSGQUEUE_OBJ_t msg;
		osSemaphoreAcquire(binary_sem_id, osWaitForever); //the second argument here is a timeout value
		//double check this, i decided to go for wait forever
		gyro_data_y = find_gyro_rotation_y();
		//Normally in the examples CMSIS gives you call osSemaphoreRelease here but
		//I think that in our implementation, the timer callback takes care of that

		//the below part needs to be checked, no clue if this is correct
		msg.gyro_data = gyro_data;
		msg.data_sent = 0;
		osMessageQueuePut(mid_MsgQueue, &msg, 0U, 0U);
		//osThreadYield();

	}

}
