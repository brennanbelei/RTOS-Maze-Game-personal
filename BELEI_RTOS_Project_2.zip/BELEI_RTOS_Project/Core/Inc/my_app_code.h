/*
 * Application_Code.h
 *
 *  Created on: Jan 24, 2024
 *      Author: brenn
 */

#ifndef INC_APPLICATION_CODE_H_
#define INC_APPLICATION_CODE_H_

#include "stm32f4xx_hal.h"
#include <Gyro_Driver.h>
#include "cmsis_os.h"

//Port and Pin defs
#define USR_BTN_PORT	GPIOA
#define USR_BTN_PIN		GPIO_PIN_0
#define GRN_LED_PORT	GPIOG
#define GRN_LED_PIN		GPIO_PIN_13
#define RED_LED_PORT	GPIOG
#define RED_LED_PIN		GPIO_PIN_14
#define MAZE_HEIGHT		256	//come back and fix these values
#define MAZE_WIDTH		256 //come back and fix these values



//define global variable to store direction of the gyro rotation
typedef enum{
	//this will have 5 different values
	CCW_FAST,
	CCW_SLOW,
	NEAR_ZERO,
	CW_FAST,
	CW_SLOW,

}gyro_dir;



//begin maze struct definition
typedef struct{
	char cells[MAZE_HEIGHT][MAZE_WIDTH];
} Maze;


//end maze struct definition

//begin initialization function declarations
void app_init();

void phys_timer_init();

void LCD_timer_init();

void event_init();

void mutex_init();

void task_init();
//end initialization function declarations

//begin task function declarations
void drive_LED_task();

void coll_detect_task();

void phys_engine_task();

void game_logic_task();

void LCD_display_task();
//end task function declarations

//begin helper function declarations
void btn_status();

gyro_dir find_gyro_rotation();

void maze_gen();

void gyro_tilt_calc();
//end helper function declarations



////GPIO_PinState sample_btn_status();
////gyro_dir find_gyro_rotation();
////void drive_LEDs();
//
///*
// * @brief This is the function that samples the status of the user button
// * both the part 1 sampling method and part 2 interrupt method use this function
// *
// * @param[in](void)
// * @return (void)
// */
//
//void sample_btn_status();
//
///*
// * @brief This is the function that calculate the rotation of the gyro
// * it relies on using the provided gyro driver
// *
// * @param[in](void)
// * @return (void)
// */
//gyro_dir find_gyro_rotation();
//
///*
// * @brief This is the function that drives the LEDs according to
// * the measurements of the gyro as well as the status of the user button.
// * The if statements are tailored such that the test cases as established by
// * the lab write up pass accordingly.
// *
// *
// * @param[in](void)
// * @return (void)
// */
//
//void drive_LEDs();
//
///*
// * @brief This is the initialization function for my app, it initializes the gyro and the
// * appropriate interrupts using the NVIC
// *
// *
// * @param[in](void)
// * @return (void)
// */


#endif /* INC_APPLICATION_CODE_H_ */
