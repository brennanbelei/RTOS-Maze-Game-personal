/*
 * maze_gen_test.c
 *
 *  Created on: Apr 20, 2024
 *      Author: brenn
 */

#include "maze_gen_test.h"


Point stack[(MAZE_WIDTH) * (MAZE_HEIGHT)];
int stack_top = -1;
int prev_stack_top = -1;
Point starting_cell;
Point final_cell;

int maze[MAZE_HEIGHT][MAZE_WIDTH];
int visited_cells = 0;
//bool wall_pixels[MAZE_HEIGHT * (PATH_WIDTH + 1)][MAZE_WIDTH * (PATH_WIDTH + 1)];

//NOTE: the increments and decrements in push and pop change the global variable stack_top
void push(int x, int y) {
    stack[++stack_top].x = x;
    stack[stack_top].y = y;
}

Point pop() {
	if(stack_top >= 0){
		return stack[stack_top--];
	}
	else{
		while(1);
	}
    //return stack[stack_top--];
}

bool is_empty() {
    return (stack_top == -1);
}

bool is_complete(){
	if(prev_stack_top == stack_top){
		return true;
	}
	else{
		return false;
	}
}

void init_maze() {
    for (int y = 0; y < MAZE_HEIGHT; y++) {
        for (int x = 0; x < MAZE_WIDTH; x++) {
            maze[y][x] = 0;
        }
    }

    int x = (osKernelGetSysTimerCount()+5) % MAZE_WIDTH;
    int y = (osKernelGetSysTimerCount()+5) % MAZE_HEIGHT;
//    int x = rand() % MAZE_WIDTH;
//    int y = rand() % MAZE_HEIGHT;
    push(x, y);
    maze[y][x] = CELL_VISITED;
    visited_cells = 1;
    starting_cell = stack[stack_top];
}

bool update_maze() {
	prev_stack_top = stack_top;
    if (visited_cells < (MAZE_WIDTH * MAZE_HEIGHT)) {
        Point current = stack[stack_top];
        int neighbors[4] = {0};
        int neighbor_count = 0;

        // North neighbor
        if (current.y > 0 && !(maze[current.y - 1][current.x] & CELL_VISITED)) {
            neighbors[neighbor_count++] = 0;
        }
        // East neighbor
        if (current.x < MAZE_WIDTH - 1 && !(maze[current.y][current.x + 1] & CELL_VISITED)) {
            neighbors[neighbor_count++] = 1;
        }
        // South neighbor
        if (current.y < MAZE_HEIGHT - 1 && !(maze[current.y + 1][current.x] & CELL_VISITED)) {
            neighbors[neighbor_count++] = 2;
        }
        // West neighbor
        if (current.x > 0 && !(maze[current.y][current.x - 1] & CELL_VISITED)) {
            neighbors[neighbor_count++] = 3;
        }

        if (neighbor_count > 0) {
            int next_cell_dir = neighbors[rand() % neighbor_count];
            int next_x = current.x, next_y = current.y;

            switch (next_cell_dir) {
                case 0: // North
                	//indicating the northern movement is in the negative y direction
                    maze[current.y][current.x] |= CELL_PATH_N;
                    maze[current.y - 1][current.x] |= CELL_VISITED | CELL_PATH_S;
                    next_y--;
                    break;
                case 1: // East
                	//indicating the eastward movement is in the positive x direction
                    maze[current.y][current.x] |= CELL_PATH_E;
                    maze[current.y][current.x + 1] |= CELL_VISITED | CELL_PATH_W;
                    next_x++;
                    break;
                case 2: // South
                	//indicating the southern movement is in the positive y direction
                    maze[current.y][current.x] |= CELL_PATH_S;
                    maze[current.y + 1][current.x] |= CELL_VISITED | CELL_PATH_N;
                    next_y++;
                    break;
                case 3: // West
                	//indicating the westward movement is in the negative x direction
                    maze[current.y][current.x] |= CELL_PATH_W;
                    maze[current.y][current.x - 1] |= CELL_VISITED | CELL_PATH_E;
                    next_x--;
                    break;
            }
            if((next_x <= MAZE_HEIGHT && next_x >= 0) && (next_y <= MAZE_HEIGHT && next_y >= 0)){
            	//save the value of the prev_stack_top before it gets incremented
            	//prev_stack_top = stack_top;
            	push(next_x, next_y);
            	visited_cells++;
            }
            else{
            	while(1);
            }
//          push(next_x, next_y);
//          visited_cells++;
        }
        else {
        	//save the value of the prev_stack_top before it gets incremented
        	//prev_stack_top = stack_top;
        	pop();
        }
    }
}

bool draw_maze() {
    for (int y = 0; y < MAZE_HEIGHT; y++) {
        for (int x = 0; x < MAZE_WIDTH; x++) {
            int cell_x = (x * (PATH_WIDTH + 1)) + X_SHIFT;
            int cell_y = (y * (PATH_WIDTH + 1)) + Y_SHIFT;

            if (maze[y][x] & CELL_VISITED) {
                // Draw a white cell
                for (int py = 0; py < PATH_WIDTH; py++) {
                    for (int px = 0; px < PATH_WIDTH; px++) {
                        LCD_Draw_Pixel(cell_x + px, cell_y + py, LCD_COLOR_WHITE);
                    }
                }
            } else {
                // Draw a blue cell
                for (int py = 0; py < PATH_WIDTH; py++) {
                    for (int px = 0; px < PATH_WIDTH; px++) {
                        LCD_Draw_Pixel(cell_x + px, cell_y + py, LCD_COLOR_BLUE);
                    }
                }
            }

            // Draw passageways between cells
            if (maze[y][x] & CELL_PATH_S) {
                for (int p = 0; p < PATH_WIDTH; p++) {
                    LCD_Draw_Pixel(cell_x + p, cell_y + PATH_WIDTH, LCD_COLOR_WHITE);
                    //added the below line to populate the wall pixels array for coll
//                   wall_pixels[cell_y + PATH_WIDTH][cell_x + p] = true;
                }
            }

            if (maze[y][x] & CELL_PATH_E) {
                for (int p = 0; p < PATH_WIDTH; p++) {
                    LCD_Draw_Pixel(cell_x + PATH_WIDTH, cell_y + p, LCD_COLOR_WHITE);
                    //added the below line to populate the wall pixels array for coll
//                    wall_pixels[cell_y + p][cell_x + PATH_WIDTH] = true;
                }
            }
//            int middle_x = cell_x + (PATH_WIDTH / 2);
//            int middle_y = cell_y + (PATH_WIDTH / 2);
//            LCD_SetTextColor(LCD_COLOR_BLACK);
//            LCD_SetFont(&Font12x12);
//            LCD_DisplayNumber(middle_x, middle_y, x); // Display x coordinate
//            LCD_DisplayNumber(middle_x, middle_y + 10, y); // Display y coordinat
        }
    }

    // Draw the current cell (top of the stack)
    Point current = stack[stack_top];
    final_cell = current;
    int current_x = (current.x * (PATH_WIDTH + 1)) + X_SHIFT;
    int current_y = current.y * (PATH_WIDTH + 1) + Y_SHIFT;
    for (int py = 0; py < PATH_WIDTH; py++) {
        for (int px = 0; px < PATH_WIDTH; px++) {
            LCD_Draw_Pixel(current_x + px, current_y + py, LCD_COLOR_GREEN);
        }
    }

    bool empty_status = is_empty();
    bool complete_status = is_complete();
    if(complete_status == true){
    	//this is the cell that the maze ended on before it completed
    	final_cell = current;
    }
    return complete_status;

}


