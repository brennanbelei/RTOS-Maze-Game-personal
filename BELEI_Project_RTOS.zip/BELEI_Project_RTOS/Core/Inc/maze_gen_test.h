/*
 * maze_gen_test.h
 *
 *  Created on: Apr 20, 2024
 *      Author: brenn
 */

#ifndef INC_MAZE_GEN_TEST_H_
#define INC_MAZE_GEN_TEST_H_

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <stdbool.h>
#include "stm32f4xx_hal.h"
#include "cmsis_os.h"
#include <math.h>
#include "LCD_Driver.h"

#define MAZE_WIDTH 12 //was 8
#define MAZE_HEIGHT 12
#define PATH_WIDTH 15 //was 20
#define X_SHIFT 0
#define Y_SHIFT 0

// Bit fields for convenience
#define CELL_PATH_N 0x01
#define CELL_PATH_E 0x02
#define CELL_PATH_S 0x04
#define CELL_PATH_W 0x08
#define CELL_VISITED 0x10

typedef struct {
    int x;
    int y;
} Point;

extern int maze[MAZE_HEIGHT][MAZE_WIDTH];

extern Point final_cell;

void push(int x, int y);

Point pop();

bool is_empty();

void init_maze() ;

bool update_maze();

bool draw_maze();

#endif /* INC_MAZE_GEN_TEST_H_ */
